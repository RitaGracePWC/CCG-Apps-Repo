sap.ui.define([
	"CCGSDGRADINGAPP/ZSD_GRADINGAPP/test/unit/controller/grading.controller"
], function () {
	"use strict";
});