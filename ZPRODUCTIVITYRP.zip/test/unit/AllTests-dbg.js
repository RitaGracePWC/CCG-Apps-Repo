sap.ui.define([
	"sap/ops/productivityreport/ZOPSPRODUCTIVITYREPORT/test/unit/controller/Report.controller"
], function () {
	"use strict";
});